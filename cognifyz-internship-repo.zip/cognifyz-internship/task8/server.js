// server.js
// Task 8: Advanced Server-Side Functionality
// Objective: Implement advanced server-side features for a robust application.

const express = require('express');
const session = require('express-session');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const rateLimit = require('express-rate-limit');
const crypto = require('crypto');
const Database = require('better-sqlite3');
const path = require('path');

const app = express();
const PORT = 3000;
const JWT_SECRET = 'cognifyz-task8-oauth-secret';

app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

// ================= Step 1: Middleware for request processing =================

// 1a. Request-ID middleware — tags every request with a unique ID, useful for
// tracing a single request through logs.
app.use((req, res, next) => {
  req.requestId = crypto.randomBytes(6).toString('hex');
  res.setHeader('X-Request-Id', req.requestId);
  next();
});

// 1b. Logging middleware — logs method, path, status code, and response time
// for every request. Kept in a small in-memory ring buffer so it can also be
// inspected via an API route (handy for demoing without a real log service).
const requestLog = [];
app.use((req, res, next) => {
  const start = Date.now();
  res.on('finish', () => {
    const entry = {
      id: req.requestId,
      method: req.method,
      path: req.originalUrl,
      status: res.statusCode,
      durationMs: Date.now() - start,
      time: new Date().toISOString()
    };
    requestLog.push(entry);
    if (requestLog.length > 200) requestLog.shift(); // cap memory usage
    console.log(`[${entry.time}] ${entry.method} ${entry.path} -> ${entry.status} (${entry.durationMs}ms) [${entry.id}]`);
  });
  next();
});

// ================= Database (carried over) =================
const db = new Database(path.join(__dirname, 'app.db'));
db.exec(`
  CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT UNIQUE NOT NULL,
    password_hash TEXT NOT NULL
  );
  CREATE TABLE IF NOT EXISTS tasks (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    title TEXT NOT NULL,
    done INTEGER NOT NULL DEFAULT 0,
    FOREIGN KEY (user_id) REFERENCES users(id)
  );
  CREATE TABLE IF NOT EXISTS oauth_clients (
    client_id TEXT PRIMARY KEY,
    client_secret_hash TEXT NOT NULL
  );
`);

const seedClient = db.prepare('SELECT client_id FROM oauth_clients WHERE client_id = ?').get('demo-client');
if (!seedClient) {
  const hash = bcrypt.hashSync('demo-secret-123', 10);
  db.prepare('INSERT INTO oauth_clients (client_id, client_secret_hash) VALUES (?, ?)').run('demo-client', hash);
}

app.use(session({
  secret: 'cognifyz-task8-session-secret',
  resave: false,
  saveUninitialized: false,
  cookie: { httpOnly: true, maxAge: 1000 * 60 * 60 * 4 }
}));

const apiLimiter = rateLimit({ windowMs: 15 * 60 * 1000, max: 100, standardHeaders: true, legacyHeaders: false,
  message: { error: 'Too many requests. Please try again later.' } });
app.use('/api', apiLimiter);

const authLimiter = rateLimit({ windowMs: 15 * 60 * 1000, max: 10, standardHeaders: true, legacyHeaders: false,
  message: { error: 'Too many auth attempts. Please wait before trying again.' } });

function catchAsync(fn) { return (req, res, next) => fn(req, res, next).catch(next); }
class ApiError extends Error { constructor(status, message) { super(message); this.status = status; } }

function requireAuth(req, res, next) {
  if (!req.session.userId) return res.status(401).json({ error: 'Not authenticated. Please log in.' });
  next();
}

// ================= OAuth2 client-credentials flow (Task 7) =================
app.post('/api/oauth/token', authLimiter, catchAsync(async (req, res) => {
  const { grant_type, client_id, client_secret } = req.body;
  if (grant_type !== 'client_credentials') throw new ApiError(400, 'Unsupported grant_type. Use "client_credentials".');
  if (!client_id || !client_secret) throw new ApiError(400, 'client_id and client_secret are required.');

  const client = db.prepare('SELECT * FROM oauth_clients WHERE client_id = ?').get(client_id);
  if (!client) throw new ApiError(401, 'Invalid client credentials.');
  const validSecret = await bcrypt.compare(client_secret, client.client_secret_hash);
  if (!validSecret) throw new ApiError(401, 'Invalid client credentials.');

  const accessToken = jwt.sign({ client_id, scope: 'external:read' }, JWT_SECRET, { expiresIn: '1h' });
  res.json({ access_token: accessToken, token_type: 'Bearer', expires_in: 3600, scope: 'external:read' });
}));

function requireOAuth(req, res, next) {
  const authHeader = req.headers.authorization || '';
  const token = authHeader.startsWith('Bearer ') ? authHeader.slice(7) : null;
  if (!token) return res.status(401).json({ error: 'Missing Bearer token.' });
  jwt.verify(token, JWT_SECRET, (err, payload) => {
    if (err) return res.status(401).json({ error: 'Invalid or expired token.' });
    req.oauth = payload;
    next();
  });
}

// ================= Step 3: Server-side caching =================
// Simple in-memory cache with a time-to-live (TTL). In production this would
// typically be Redis so the cache is shared across multiple server
// instances; here it demonstrates the same pattern in-process.
const cache = new Map(); // key -> { value, expiresAt }

function cacheGet(key) {
  const entry = cache.get(key);
  if (!entry) return null;
  if (Date.now() > entry.expiresAt) { cache.delete(key); return null; }
  return entry.value;
}
function cacheSet(key, value, ttlMs) {
  cache.set(key, { value, expiresAt: Date.now() + ttlMs });
}

const WEATHER_CACHE_TTL_MS = 5 * 60 * 1000; // 5 minutes

app.get('/api/external/weather', requireOAuth, catchAsync(async (req, res) => {
  const lat = req.query.lat || '22.5726';
  const lon = req.query.lon || '88.3639';
  const cacheKey = `weather:${lat}:${lon}`;

  const cached = cacheGet(cacheKey);
  if (cached) {
    return res.json({ ...cached, cached: true });
  }

  const url = `https://api.open-meteo.com/v1/forecast?latitude=${lat}&longitude=${lon}&current_weather=true`;
  let externalRes;
  try {
    externalRes = await fetch(url);
  } catch (err) {
    throw new ApiError(502, 'Could not reach the external weather service.');
  }
  if (!externalRes.ok) throw new ApiError(502, 'External weather service returned an error.');

  const data = await externalRes.json();
  const payload = {
    source: 'open-meteo.com',
    requested_by_client: req.oauth.client_id,
    location: { lat: Number(lat), lon: Number(lon) },
    current_weather: data.current_weather
  };

  cacheSet(cacheKey, payload, WEATHER_CACHE_TTL_MS);
  res.json({ ...payload, cached: false });
}));

// ================= Step 2: Background job processing =================
// A minimal in-memory job queue + single worker loop, standing in for a real
// task queue (e.g. Bull/BullMQ backed by Redis) without needing external
// infrastructure. Demonstrates: enqueue -> queued -> processing -> completed.
const jobs = new Map(); // jobId -> { status, result, error, createdAt }
const jobQueue = [];

function enqueueJob(type, payload) {
  const id = crypto.randomBytes(8).toString('hex');
  jobs.set(id, { id, type, status: 'queued', result: null, error: null, createdAt: new Date().toISOString() });
  jobQueue.push(id);
  return id;
}

async function processJob(jobId) {
  const job = jobs.get(jobId);
  if (!job) return;
  job.status = 'processing';

  try {
    if (job.type === 'export-tasks') {
      // Simulate a slow background operation (e.g. generating a report)
      await new Promise(resolve => setTimeout(resolve, 3000));
      const rows = db.prepare('SELECT id, title, done FROM tasks WHERE user_id = ?').all(job.payload.userId);
      const csv = ['id,title,done', ...rows.map(r => `${r.id},"${r.title.replace(/"/g, '""')}",${r.done}`)].join('\n');
      job.result = csv;
    }
    job.status = 'completed';
  } catch (err) {
    job.status = 'failed';
    job.error = err.message;
  }
}

// Worker loop: picks up one queued job at a time, every 500ms
setInterval(() => {
  if (jobQueue.length === 0) return;
  const nextId = jobQueue.shift();
  processJob(nextId);
}, 500);

// Enqueue a background export job for the logged-in user's tasks
app.post('/api/jobs/export-tasks', requireAuth, (req, res) => {
  const id = enqueueJob('export-tasks', { userId: req.session.userId });
  jobs.get(id).payload = { userId: req.session.userId };
  res.status(202).json({ jobId: id, status: 'queued' }); // 202 Accepted: processing happens async
});

// Poll for job status/result
app.get('/api/jobs/:id', requireAuth, (req, res) => {
  const job = jobs.get(req.params.id);
  if (!job) return res.status(404).json({ error: 'Job not found.' });
  res.json({ id: job.id, type: job.type, status: job.status, result: job.result, error: job.error });
});

// ================= Auth endpoints (carried over) =================
app.post('/api/auth/register', authLimiter, catchAsync(async (req, res) => {
  const { username, password } = req.body;
  if (!username || !password || password.length < 6) throw new ApiError(400, 'Username required, password must be 6+ characters.');
  const existing = db.prepare('SELECT id FROM users WHERE username = ?').get(username);
  if (existing) throw new ApiError(409, 'Username already taken.');
  const hash = await bcrypt.hash(password, 10);
  const info = db.prepare('INSERT INTO users (username, password_hash) VALUES (?, ?)').run(username, hash);
  req.session.userId = info.lastInsertRowid;
  req.session.username = username;
  res.status(201).json({ id: info.lastInsertRowid, username });
}));

app.post('/api/auth/login', authLimiter, catchAsync(async (req, res) => {
  const { username, password } = req.body;
  const user = db.prepare('SELECT * FROM users WHERE username = ?').get(username);
  if (!user) throw new ApiError(401, 'Invalid username or password.');
  const match = await bcrypt.compare(password, user.password_hash);
  if (!match) throw new ApiError(401, 'Invalid username or password.');
  req.session.userId = user.id;
  req.session.username = user.username;
  res.json({ id: user.id, username: user.username });
}));

app.post('/api/auth/logout', (req, res) => { req.session.destroy(() => res.json({ ok: true })); });

app.get('/api/auth/me', (req, res) => {
  if (!req.session.userId) return res.status(401).json({ error: 'Not authenticated.' });
  res.json({ id: req.session.userId, username: req.session.username });
});

// ================= Task API (carried over) =================
app.get('/api/tasks', requireAuth, (req, res) => {
  res.json(db.prepare('SELECT * FROM tasks WHERE user_id = ?').all(req.session.userId));
});

app.post('/api/tasks', requireAuth, catchAsync(async (req, res) => {
  const { title } = req.body;
  if (!title || !title.trim()) throw new ApiError(400, 'Title is required.');
  const info = db.prepare('INSERT INTO tasks (user_id, title, done) VALUES (?, ?, 0)').run(req.session.userId, title.trim());
  res.status(201).json({ id: info.lastInsertRowid, user_id: req.session.userId, title: title.trim(), done: 0 });
}));

app.put('/api/tasks/:id', requireAuth, catchAsync(async (req, res) => {
  const task = db.prepare('SELECT * FROM tasks WHERE id = ? AND user_id = ?').get(req.params.id, req.session.userId);
  if (!task) throw new ApiError(404, 'Task not found.');
  const title = req.body.title !== undefined ? req.body.title.trim() : task.title;
  const done = req.body.done !== undefined ? (req.body.done ? 1 : 0) : task.done;
  db.prepare('UPDATE tasks SET title = ?, done = ? WHERE id = ?').run(title, done, task.id);
  res.json({ ...task, title, done });
}));

app.delete('/api/tasks/:id', requireAuth, catchAsync(async (req, res) => {
  const task = db.prepare('SELECT * FROM tasks WHERE id = ? AND user_id = ?').get(req.params.id, req.session.userId);
  if (!task) throw new ApiError(404, 'Task not found.');
  db.prepare('DELETE FROM tasks WHERE id = ?').run(task.id);
  res.json(task);
}));

// Admin/demo route to inspect the request log produced by our logging middleware
app.get('/api/admin/logs', requireAuth, (req, res) => {
  res.json(requestLog.slice(-50));
});

// ================= Error handling =================
app.use('/api', (req, res) => res.status(404).json({ error: 'API route not found.' }));

app.use((err, req, res, next) => {
  const status = err.status || 500;
  if (status === 500) console.error(`[${req.requestId}]`, err);
  res.status(status).json({ error: err.message || 'Internal server error.' });
});

app.listen(PORT, () => {
  console.log(`Server running at http://localhost:${PORT}`);
});
