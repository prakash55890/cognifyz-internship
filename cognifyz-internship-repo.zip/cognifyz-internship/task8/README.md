# Task 8 — Advanced Server-Side Functionality
Cognifyz Full Stack Development Internship

## Objective
Implement advanced server-side features for a robust application.

## What this covers

### 1. Middleware for request processing
- **Request-ID middleware**: tags every request with a unique ID
  (`X-Request-Id` response header) for tracing a single request through logs.
- **Logging middleware**: logs method, path, status code, and response time
  for every request to the console, and keeps the last 200 in memory —
  viewable via `GET /api/admin/logs` (while logged in).

### 2. Background job processing
A lightweight in-memory job queue + worker (`GET/POST /api/jobs/...`),
standing in for a real task queue (e.g. **BullMQ + Redis** in production)
without needing external infrastructure:
- `POST /api/jobs/export-tasks` queues a "export my tasks to CSV" job and
  returns immediately with `202 Accepted` + a `jobId` — the request is
  **not** blocked while the work happens.
- A background worker loop picks up queued jobs every 500ms and processes
  them (simulated with a 3s delay, like a real report-generation job would
  take).
- `GET /api/jobs/:id` lets the client poll for `queued` → `processing` →
  `completed` (with the CSV result) or `failed`.
- Try it from the "Background Job Demo" card on the page.

### 3. Server-side caching
An in-memory cache with a TTL wraps the external weather call from Task 7
(`GET /api/external/weather`): the first request for a given lat/lon fetches
live from Open-Meteo and caches the result for **5 minutes**; repeat
requests within that window are served from cache (`"cached": true` in the
response) instead of hitting the external API again. In production this
would typically be Redis, shared across multiple server instances — here it
demonstrates the same pattern in-process.

## How to run
```bash
npm install
node server.js
```
Open **http://localhost:3000**, register/log in, then try the Background
Job and External API cards.

## Tested behavior
- `X-Request-Id` header present on every response
- Queuing an export job returns `202` instantly; polling shows
  `queued` → `completed` with the real CSV of the user's tasks after ~3s
- `/api/admin/logs` shows accurate method/path/status/duration for recent
  requests

## Carried over from Tasks 1–7
Full-stack form (Task 1-4), REST CRUD API (Task 5), SQLite + session auth
(Task 6), OAuth2 client-credentials flow + external API + rate limiting
(Task 7).
