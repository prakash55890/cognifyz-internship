# Task 6 — Database Integration and User Authentication
Cognifyz Full Stack Development Internship

## Objective
Integrate a database and implement user authentication for secure data handling.

## What this covers
1. **Database integration** — SQLite via `better-sqlite3` (file-based, needs
   no separate DB server to install). Two tables: `users` (id, username,
   password_hash) and `tasks` (id, user_id, title, done), linked by a
   foreign key so every task belongs to exactly one user.
2. **User authentication** — registration and login endpoints
   (`/api/auth/register`, `/api/auth/login`). Passwords are hashed with
   **bcrypt** before being stored — the plain password is never saved.
   Sessions are managed with `express-session` (a signed, httpOnly cookie
   holding only a session ID, not the password).
3. **Secured / authorized API endpoints** — every `/api/tasks` route is
   wrapped in a `requireAuth` middleware that rejects requests with no
   valid session (`401 Unauthorized`). Each query is also scoped to
   `WHERE user_id = ?`, so even a logged-in user can only ever see or modify
   their **own** tasks, never another user's.

## How to run
```bash
npm install
node server.js
```
Open **http://localhost:3000**. Register a new account, then log in — you'll
see the task manager from Task 5, now private to your account. A file called
`app.db` will appear in the folder — that's your SQLite database.

## Tested behavior
- Accessing `/api/tasks` while logged out → `401`
- Registering the same username twice → `409`
- Logging in with the wrong password → `401`
- Two different users cannot see each other's tasks (verified with two
  separate accounts)
- After logout, the session is destroyed and API access is blocked again

## Notes
- `app.db` is created automatically on first run; delete it to reset all
  data.
- The session secret in `server.js` is hardcoded for simplicity — in a real
  deployment it would come from an environment variable.
