// server.js
// Task 2: Inline Styles, Basic Interaction, and Server-Side Validation
// Objective: Expand inline styles and introduce server-side validation for form submissions.

const express = require('express');
const bodyParser = require('body-parser');
const path = require('path');

const app = express();
const PORT = 3000;

app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, 'public')));

// Temporary server-side storage for validated submissions (Step 4)
const submissions = [];

app.get('/', (req, res) => {
  res.render('form', { title: 'User Registration Form', errors: {}, old: {} });
});

// Server-side validation function (Step 3)
function validate(body) {
  const errors = {};
  const { name, email, age, phone, password, confirmPassword } = body;

  if (!name || name.trim().length < 2) {
    errors.name = 'Name must be at least 2 characters.';
  }

  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  if (!email || !emailRegex.test(email)) {
    errors.email = 'Please enter a valid email address.';
  }

  if (age === undefined || age === '' || isNaN(age) || Number(age) < 13 || Number(age) > 120) {
    errors.age = 'Age must be a number between 13 and 120.';
  }

  const phoneRegex = /^[0-9]{10}$/;
  if (!phone || !phoneRegex.test(phone)) {
    errors.phone = 'Phone number must be exactly 10 digits.';
  }

  if (!password || password.length < 6) {
    errors.password = 'Password must be at least 6 characters.';
  }

  if (password !== confirmPassword) {
    errors.confirmPassword = 'Passwords do not match.';
  }

  return errors;
}

// ROUTE: Handle form submission with server-side validation (Steps 3 & 4)
app.post('/submit', (req, res) => {
  const errors = validate(req.body);

  if (Object.keys(errors).length > 0) {
    return res.status(400).render('form', {
      title: 'User Registration Form',
      errors,
      old: { ...req.body, password: '', confirmPassword: '' }
    });
  }

  const entry = {
    name: req.body.name.trim(),
    email: req.body.email.trim(),
    age: req.body.age,
    phone: req.body.phone,
    submittedAt: new Date().toLocaleString()
  };
  submissions.push(entry);

  res.render('result', { entry, total: submissions.length });
});

app.get('/submissions', (req, res) => {
  res.render('list', { submissions });
});

app.listen(PORT, () => {
  console.log(`Server running at http://localhost:${PORT}`);
});
