# Task 2 — Inline Styles, Basic Interaction, and Server-Side Validation
Cognifyz Full Stack Development Internship

## Objective
Expand inline styles and introduce server-side validation for form submissions.

## What this covers
1. Extended HTML form with more fields and user interactions
   (name, email, age, phone, password, confirm password) — `views/form.ejs`
2. Inline JavaScript for client-side form validation (in `form.ejs` `<script>` block),
   plus a live password-strength hint as a basic interaction
3. Server-side validation for all submitted fields (`server.js` → `validate()`)
4. Validated data stored in temporary server-side storage (in-memory array)

## How to run
```bash
npm install
node server.js
```
Open **http://localhost:3000**.

## Validation rules (enforced both client-side and server-side)
- Name: at least 2 characters
- Email: valid email format
- Age: number between 13 and 120
- Phone: exactly 10 digits
- Password: at least 6 characters
- Confirm Password: must match Password

If the server-side check fails, the form is re-rendered with field-specific
error messages and the previously entered values (except passwords) so the
user doesn't have to retype everything.
