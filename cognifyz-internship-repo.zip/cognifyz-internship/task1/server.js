// server.js
// Task 1: HTML Structure and Basic Server Interaction
// Objective: server-side rendering + basic form submission handling

const express = require('express');
const bodyParser = require('body-parser');
const path = require('path');

const app = express();
const PORT = 3000;

// Set EJS as the templating engine for server-side rendering
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

// Middleware
app.use(bodyParser.urlencoded({ extended: true })); // parse form data (application/x-www-form-urlencoded)
app.use(express.static(path.join(__dirname, 'public'))); // serve CSS/static files

// In-memory store to simulate temporary "storage" of submissions
const submissions = [];

// ROUTE 1: Show the form (GET /)
app.get('/', (req, res) => {
  res.render('form', { title: 'User Registration Form' });
});

// ROUTE 2: Handle form submission (POST /submit)
app.post('/submit', (req, res) => {
  const { name, email, message } = req.body;

  // Basic server-side check (kept simple for Task 1 — full validation is Task 2)
  if (!name || !email) {
    return res.status(400).render('form', {
      title: 'User Registration Form',
      error: 'Name and Email are required fields.'
    });
  }

  // Store the submission
  const entry = { name, email, message, submittedAt: new Date().toLocaleString() };
  submissions.push(entry);

  // Server-side render the result page dynamically using EJS
  res.render('result', { entry, total: submissions.length });
});

// ROUTE 3: View all submissions (demonstrates dynamic list rendering)
app.get('/submissions', (req, res) => {
  res.render('list', { submissions });
});

app.listen(PORT, () => {
  console.log(`Server running at http://localhost:${PORT}`);
});
