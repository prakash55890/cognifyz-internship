# Task 1 — HTML Structure and Basic Server Interaction
Cognifyz Full Stack Development Internship

## Objective
Introduce server-side rendering and basic form submissions.

## What this covers
1. HTML structure with a form for user input (`views/form.ejs`)
2. A simple Node.js server using Express (`server.js`)
3. Server-side endpoints to handle form submissions (`POST /submit`)
4. Server-side rendering using EJS to dynamically generate HTML
   (`views/result.ejs`, `views/list.ejs`)

## How to run
```bash
npm install
node server.js
```
Then open **http://localhost:3000** in your browser.

## Routes
| Method | Route         | Purpose                                   |
|--------|---------------|--------------------------------------------|
| GET    | `/`           | Shows the input form                       |
| POST   | `/submit`     | Handles form submission, renders a result  |
| GET    | `/submissions`| Lists all submissions received so far      |

## Notes
- Submitted data is stored temporarily in memory (resets on server restart).
- Basic required-field checking is done here; full validation rules are
  covered in Task 2 (Inline Styles, Basic Interaction, and Server-Side
  Validation).
