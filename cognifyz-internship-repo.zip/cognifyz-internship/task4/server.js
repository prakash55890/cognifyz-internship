// server.js
// Task 4: Complex Form Validation and Dynamic DOM Manipulation
// Objective: Extend form validation and implement dynamic updates to the DOM.

const express = require('express');
const bodyParser = require('body-parser');
const path = require('path');

const app = express();
const PORT = 3000;

app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, 'public')));

const submissions = [];

app.get('/', (req, res) => {
  res.render('form', { title: 'User Registration', error: null });
});

// Step 1 (server-side counterpart): complex password rules, matching the
// client-side checklist shown live in Step 2 of the form.
function checkPasswordRules(pw) {
  return {
    length: pw && pw.length >= 8,
    upper: /[A-Z]/.test(pw || ''),
    lower: /[a-z]/.test(pw || ''),
    number: /[0-9]/.test(pw || ''),
    special: /[!@#$%^&*]/.test(pw || '')
  };
}

function validate(body) {
  const errors = [];
  const { name, email, age, phone, password, confirmPassword, skills } = body;

  if (!name || name.trim().length < 2) errors.push('Name must be at least 2 characters.');

  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  if (!email || !emailRegex.test(email)) errors.push('Please enter a valid email address.');

  if (age === undefined || age === '' || isNaN(age) || Number(age) < 13 || Number(age) > 120) {
    errors.push('Age must be a number between 13 and 120.');
  }

  const phoneRegex = /^[0-9]{10}$/;
  if (!phone || !phoneRegex.test(phone)) errors.push('Phone number must be exactly 10 digits.');

  const pwRules = checkPasswordRules(password);
  if (!Object.values(pwRules).every(Boolean)) {
    errors.push('Password must be 8+ characters with uppercase, lowercase, a number, and a special character.');
  }

  if (password !== confirmPassword) errors.push('Passwords do not match.');

  if (!skills || skills.trim().length === 0) errors.push('At least one skill is required.');

  return errors;
}

app.post('/submit', (req, res) => {
  const errors = validate(req.body);

  if (errors.length > 0) {
    return res.status(400).render('form', {
      title: 'User Registration',
      error: errors.join(' ')
    });
  }

  const entry = {
    name: req.body.name.trim(),
    email: req.body.email.trim(),
    age: req.body.age,
    phone: req.body.phone,
    skills: req.body.skills.split(',').map(s => s.trim()).filter(Boolean),
    submittedAt: new Date().toLocaleString()
  };
  submissions.push(entry);

  res.render('result', { entry, total: submissions.length });
});

app.get('/submissions', (req, res) => {
  res.render('list', { submissions });
});

app.listen(PORT, () => {
  console.log(`Server running at http://localhost:${PORT}`);
});
