# Task 4 — Complex Form Validation and Dynamic DOM Manipulation
Cognifyz Full Stack Development Internship

## Objective
Extend form validation and implement dynamic updates to the DOM.

## What this covers
1. **Complex validation rules** — password must be 8+ characters with an
   uppercase letter, a lowercase letter, a number, and a special character
   (`!@#$%^&*`). Enforced both live in the browser (checklist ticks green as
   you type) and again on the server (`server.js` → `checkPasswordRules`).
2. **Dynamic DOM manipulation**:
   - Password rule checklist updates live (✅/○) as the user types
   - Skill tags can be added and removed on the fly — each tag and its
     remove button are created/destroyed in the DOM via JavaScript
     (`renderSkillTags()` in `form.ejs`)
   - The Review step (Step 4) is built dynamically from whatever the user
     entered in the earlier steps
   - The progress bar and step labels update as the user moves between steps
3. **Client-side routing** — the form is a single page split into 4 steps
   (Personal → Security → Skills → Review). Moving between steps updates the
   URL hash (`#step1`, `#step2`, …) with no full page reload, and the
   browser's back/forward buttons work correctly via the `hashchange` event.

## How to run
```bash
npm install
node server.js
```
Open **http://localhost:3000**.

## Notes
- Each step is validated before you can click "Next".
- Skills are sent to the server as a comma-separated hidden field and stored
  as an array per submission.
- Server-side validation mirrors the client-side rules, so a submission
  can't bypass the checks by skipping JavaScript.
