# Task 3 — Advanced CSS Styling and Responsive Design
Cognifyz Full Stack Development Internship

## Objective
Enhance CSS styling and make the webpage fully responsive.

## What this covers
1. **Multi-section layout** (`views/form.ejs`): navbar → hero → feature
   highlights (3-column) → registration form → footer
2. **Advanced CSS** (`public/style.css`): gradient backgrounds, `@keyframes`
   fade-in animation on the hero, hover transitions on feature cards and the
   submit button, custom `@media` breakpoints on top of Bootstrap's own
3. **Bootstrap 5** (via CDN) for a consistent, responsive grid — the layout
   reflows from a 3-column feature section on desktop to a single column on
   mobile, and the form card resizes across breakpoints (`col-12 col-md-8
   col-lg-6`)

## How to run
```bash
npm install
node server.js
```
Open **http://localhost:3000** — resize the browser window to see the
responsive behavior (feature cards stack on mobile, hero text shrinks below
576px).

## Carried over from Task 1 & 2
- Express + EJS server-side rendering
- Full client-side + server-side form validation
- Temporary in-memory storage of validated submissions
