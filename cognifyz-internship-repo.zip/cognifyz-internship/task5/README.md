# Task 5 — API Integration and Front-End Interaction
Cognifyz Full Stack Development Internship

## Objective
Introduce server-client communication through a RESTful API.

## What this covers
1. **RESTful API endpoints for CRUD** (`server.js`):
   | Method | Route            | Action                        |
   |--------|------------------|--------------------------------|
   | GET    | `/api/tasks`     | List all tasks                 |
   | GET    | `/api/tasks/:id` | Get one task                   |
   | POST   | `/api/tasks`     | Create a task                  |
   | PUT    | `/api/tasks/:id` | Update a task's title/done      |
   | DELETE | `/api/tasks/:id` | Delete a task                  |
2. **Front-end interface** (`public/index.html`) — a Task Manager UI that
   talks only to its own API above using `fetch()`: add a task, check it off,
   or delete it, all without a page reload.
3. **Fetch and display data** — on page load, the front end calls
   `GET /api/tasks` and renders the list dynamically; every add/toggle/delete
   re-fetches and re-renders so the UI always reflects server state.

## How to run
```bash
npm install
node server.js
```
Open **http://localhost:3000**.

## Notes
- Data is stored in memory (`server.js`), so it resets on server restart.
- Both client-side and server-side reject an empty task title.
