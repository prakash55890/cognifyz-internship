// server.js
// Task 5: API Integration and Front-End Interaction
// Objective: Introduce server-client communication through a RESTful API.

const express = require('express');
const bodyParser = require('body-parser');
const path = require('path');

const app = express();
const PORT = 3000;

app.use(bodyParser.json());
app.use(express.static(path.join(__dirname, 'public')));

// In-memory "database" of tasks
let tasks = [
  { id: 1, title: 'Complete Task 5', done: false },
  { id: 2, title: 'Review pull requests', done: true }
];
let nextId = 3;

// ---------- Step 1: RESTful API endpoints for CRUD operations ----------

// READ all tasks
app.get('/api/tasks', (req, res) => {
  res.json(tasks);
});

// READ one task
app.get('/api/tasks/:id', (req, res) => {
  const task = tasks.find(t => t.id === Number(req.params.id));
  if (!task) return res.status(404).json({ error: 'Task not found' });
  res.json(task);
});

// CREATE a task
app.post('/api/tasks', (req, res) => {
  const { title } = req.body;
  if (!title || !title.trim()) {
    return res.status(400).json({ error: 'Title is required' });
  }
  const newTask = { id: nextId++, title: title.trim(), done: false };
  tasks.push(newTask);
  res.status(201).json(newTask);
});

// UPDATE a task (title and/or done status)
app.put('/api/tasks/:id', (req, res) => {
  const task = tasks.find(t => t.id === Number(req.params.id));
  if (!task) return res.status(404).json({ error: 'Task not found' });

  if (req.body.title !== undefined) {
    if (!req.body.title.trim()) return res.status(400).json({ error: 'Title cannot be empty' });
    task.title = req.body.title.trim();
  }
  if (req.body.done !== undefined) {
    task.done = Boolean(req.body.done);
  }
  res.json(task);
});

// DELETE a task
app.delete('/api/tasks/:id', (req, res) => {
  const index = tasks.findIndex(t => t.id === Number(req.params.id));
  if (index === -1) return res.status(404).json({ error: 'Task not found' });
  const removed = tasks.splice(index, 1);
  res.json(removed[0]);
});

app.listen(PORT, () => {
  console.log(`Server running at http://localhost:${PORT}`);
});
