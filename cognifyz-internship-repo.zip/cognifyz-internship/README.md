# Cognifyz Full Stack Development Internship

All 8 tasks from the Cognifyz IT Solutions Full Stack Development internship,
each in its own folder with its own `README.md`, `package.json`, and
`node_modules`-free source.

| Task | Folder | Level | What it covers |
|------|--------|-------|-----------------|
| 1 | [`task1`](./task1) | Beginner | HTML form + Node/Express server + EJS server-side rendering |
| 2 | [`task2`](./task2) | Beginner | Inline JS validation + server-side validation |
| 3 | [`task3`](./task3) | Intermediate | Bootstrap, responsive design, CSS animations/transitions |
| 4 | [`task4`](./task4) | Intermediate | Multi-step form, hash-based client-side routing, dynamic DOM |
| 5 | [`task5`](./task5) | Advanced | RESTful CRUD API + front-end using `fetch()` |
| 6 | [`task6`](./task6) | Advanced | SQLite database + bcrypt auth + per-user secured API |
| 7 | [`task7`](./task7) | Expert | OAuth2 client-credentials flow, external weather API, rate limiting |
| 8 | [`task8`](./task8) | Expert | Custom middleware, background job queue, server-side caching |

## Running any task

Each folder is a standalone Node.js project.

```bash
cd task1        # or task2, task3, ... task8
npm install
node server.js
```

Then open **http://localhost:3000** in your browser.

## About

Built as part of the Full Stack Development internship at
[Cognifyz IT Solutions Pvt. Ltd.](https://www.cognifyz.com)

#cognifyz #cognifyzTech #cognifyzTechnologies
