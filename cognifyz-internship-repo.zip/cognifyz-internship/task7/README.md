# Task 7 — Advanced API Usage and External API Integration
Cognifyz Full Stack Development Internship

## Objective
Explore advanced API concepts and integrate external APIs.

## What this covers

### 1. OAuth2 concepts — Client Credentials Grant
`POST /api/oauth/token` implements the OAuth 2.0 **client credentials**
flow: a client (`client_id` + `client_secret`) exchanges its credentials for
a short-lived JWT **access token** (1 hour expiry). This is the standard
pattern for machine-to-machine auth (no human/browser involved), separate
from the session-based login used by the task-manager UI (Task 6).

A demo client is seeded automatically on first run:
- `client_id`: `demo-client`
- `client_secret`: `demo-secret-123`

### 2. External API integration
`GET /api/external/weather` is protected by the OAuth Bearer token above
and, when called, fetches **live data** from
[Open-Meteo](https://open-meteo.com) (a free public weather API, no key
required) and re-serves a trimmed response. Try it from the "External API
Demo" card on the page after logging in — it gets a token, then calls this
endpoint with it.

### 3. Advanced API features
- **Rate limiting** (`express-rate-limit`): general API traffic is capped at
  100 requests/15 min; auth & token endpoints are capped tighter (10/15 min)
  to slow down brute-force attempts. Exceeding the limit returns `429`.
- **Centralized error handling**: every async route is wrapped in a
  `catchAsync` helper; a custom `ApiError` class carries the right HTTP
  status; one error-handling middleware at the bottom formats every error
  as consistent JSON and logs unexpected (500) errors server-side.
- **404 handler** for unknown `/api/*` routes.
- The weather route specifically distinguishes "our server broke" from
  "the external API is down/unreachable" and returns `502` for the latter.

## How to run
```bash
npm install
node server.js
```
Open **http://localhost:3000**, register/log in, then use the task manager
(Task 5/6) or the "External API Demo" card to try the OAuth + weather flow.

## Tested behavior
- Wrong `grant_type` → `400`
- Wrong client secret → `401`
- Valid client credentials → JWT access token issued
- Calling the weather endpoint with no/invalid token → `401`
- Calling an unknown API route → `404`
- 11th+ login attempt within 15 min → `429`

## Note
This sandbox's outbound network couldn't reach `api.open-meteo.com` while
building this, so that specific call was verified to fail *gracefully*
(clean `502` from our `ApiError` handling, not a crash). On your machine,
with normal internet access, `npm install` + `node server.js` will fetch
real live weather data.
